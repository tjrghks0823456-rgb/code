-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: emotion_db
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `emotion_keywords`
--

DROP TABLE IF EXISTS `emotion_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emotion_keywords` (
  `id` int NOT NULL AUTO_INCREMENT,
  `keyword` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `emotion_code` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emotion_keywords`
--

LOCK TABLES `emotion_keywords` WRITE;
/*!40000 ALTER TABLE `emotion_keywords` DISABLE KEYS */;
INSERT INTO `emotion_keywords` VALUES (1,'행복','joy'),(2,'기쁘','joy'),(3,'좋아','joy'),(4,'신나','joy'),(5,'즐겁','joy'),(6,'설레','joy'),(7,'감사','joy'),(8,'웃음','joy'),(9,'기분좋','joy'),(10,'환희','joy'),(11,'슬프','sadness'),(12,'우울','sadness'),(13,'눈물','sadness'),(14,'괴롭','sadness'),(15,'외롭','sadness'),(16,'허전','sadness'),(17,'그립','sadness'),(18,'씁쓸','sadness'),(19,'서글프','sadness'),(20,'쓸쓸','sadness'),(21,'화나','anger'),(22,'짜증','anger'),(23,'분노','anger'),(24,'억울','anger'),(25,'열받','anger'),(26,'불쾌','anger'),(27,'짜증나','anger'),(28,'미치겠','anger'),(29,'거슬리','anger'),(30,'부아','anger'),(31,'무섭','fear'),(32,'겁나','fear'),(33,'불안','fear'),(34,'초조','fear'),(35,'두렵','fear'),(36,'긴장','fear'),(37,'떨리','fear'),(38,'위험','fear'),(39,'공포','fear'),(40,'불편','fear'),(41,'사랑','love'),(42,'좋아하','love'),(43,'그리','love'),(44,'보고싶','love'),(45,'연인','love'),(46,'애정','love'),(47,'로맨틱','love'),(48,'달콤','love'),(49,'그대','love'),(50,'마음에들','love'),(51,'그냥','neutral'),(52,'괜찮','neutral'),(53,'무난','neutral'),(54,'보통','neutral'),(55,'평범','neutral'),(56,'일상','neutral'),(57,'익숙','neutral'),(58,'담담','neutral'),(59,'차분','neutral'),(60,'조용','neutral'),(61,'희망','hope'),(62,'기대','hope'),(63,'꿈','hope'),(64,'미래','hope'),(65,'할수있','hope'),(66,'믿음','hope'),(67,'용기','hope'),(68,'포기','hope'),(69,'성공','hope'),(70,'극복','hope'),(71,'평온','calm'),(72,'조용','calm'),(73,'안정','calm'),(74,'느긋','calm'),(75,'편안','calm'),(76,'여유','calm'),(77,'차분','calm'),(78,'고요','calm'),(79,'잔잔','calm'),(80,'맑음','calm'),(81,'위로','healing'),(82,'휴식','healing'),(83,'안식','healing'),(84,'따뜻','healing'),(85,'포근','healing'),(86,'위안','healing'),(87,'편안','healing'),(88,'마음챙김','healing'),(89,'휴양','healing'),(90,'회복','healing'),(91,'피곤','tired'),(92,'졸리','tired'),(93,'지치','tired'),(94,'힘들','tired'),(95,'나른','tired'),(96,'기운없','tired'),(97,'피로','tired'),(98,'쉬고싶','tired'),(99,'무기력','tired'),(100,'휴식필요','tired');
/*!40000 ALTER TABLE `emotion_keywords` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-02 16:43:51
