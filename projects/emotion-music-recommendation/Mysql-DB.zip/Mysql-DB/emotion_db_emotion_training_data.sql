-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: emotion_db
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `emotion_training_data`
--

DROP TABLE IF EXISTS `emotion_training_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emotion_training_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_input` text COLLATE utf8mb4_general_ci NOT NULL,
  `predicted_emotion` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emotion_training_data`
--

LOCK TABLES `emotion_training_data` WRITE;
/*!40000 ALTER TABLE `emotion_training_data` DISABLE KEYS */;
INSERT INTO `emotion_training_data` VALUES (1,'슬픔','sadness','2025-11-20 09:53:26'),(2,'오늘 코딩 오류가 너무 많이나서 아침부터 힘들다 힐링하고싶지만 신나는 노래 틀어줘','joy','2025-11-20 09:54:00'),(3,'오늘 슬픈데 웃고싶어','sadness','2025-11-20 09:54:19'),(4,'오늘 슬픈데 웃고싶어','sadness','2025-11-20 09:54:20'),(5,'시발','anger','2025-11-20 09:55:25'),(6,'좆','anger','2025-11-20 09:55:36'),(7,'좆','anger','2025-11-20 09:55:37'),(8,'너 똑똑하다','joy','2025-11-20 09:55:47'),(9,'오늘 기분이 좋아요','joy','2025-11-20 09:57:02'),(10,'슬프네요','sadness','2025-11-20 09:57:08'),(11,'ㅇㄻㅇㄴㄻㄴㅇㄹ','neutral','2025-11-20 10:00:08'),(12,'아 배고파 기분좋아','joy','2025-11-20 10:03:54'),(13,'짜증나','anger','2025-11-20 10:04:09'),(14,'짜장면','neutral','2025-11-20 10:04:18'),(15,'짜장면','neutral','2025-11-20 10:04:20'),(16,'','neutral','2025-11-20 10:04:27'),(17,'','neutral','2025-11-20 10:04:28'),(18,'','neutral','2025-11-20 10:05:08'),(19,'짜장면','neutral','2025-11-20 10:05:19'),(20,'댓글이 안달려서 스트레스 받아','sadness','2025-11-20 10:05:53'),(21,'아우 패고싶어','anger','2025-11-20 10:05:58'),(22,'골든 듣고싶다','joy','2025-11-20 10:07:38'),(23,'골든 듣고싶다','joy','2025-11-20 10:07:39'),(24,'black pink노래 듣고싶어','joy','2025-11-20 10:08:10'),(25,'짜증나','anger','2025-11-20 10:21:48'),(26,'슬픔','sadness','2025-11-20 10:25:29'),(27,'감정통계보기떄문에 감정상함','sadness','2025-11-20 10:40:15'),(28,'ㅇㄹ','neutral','2025-11-20 10:53:58'),(29,'어제 오랜만에 운동을 했더니 온몸이 아파서 움직이지를 못하겠어','sadness','2025-11-20 10:54:42'),(30,'다 만든거 같아서 기쁘다','joy','2025-11-20 11:39:37'),(31,'','neutral','2025-11-20 11:39:50'),(32,'','neutral','2025-11-20 11:39:51'),(33,'기쁘다','joy','2025-11-20 11:40:03'),(34,'','neutral','2025-11-20 11:40:12'),(35,'나 오늘 우울하고 슬퍼ㅜㅜ','sadness','2025-11-20 11:43:47'),(36,'슬픔','sadness','2025-12-02 16:38:20');
/*!40000 ALTER TABLE `emotion_training_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-02 16:43:51
