-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: emotion_db
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `emotion_comments`
--

DROP TABLE IF EXISTS `emotion_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emotion_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `emotion_code` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `comment_text` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emotion_comments`
--

LOCK TABLES `emotion_comments` WRITE;
/*!40000 ALTER TABLE `emotion_comments` DISABLE KEYS */;
INSERT INTO `emotion_comments` VALUES (1,'sadness','ㅇㅇㅇ','2025-11-13 01:52:40'),(2,'sadness','dfdf','2025-11-13 02:08:50'),(3,'sadness','세종아 빨리해라','2025-11-13 02:09:03'),(4,'sadness','ㅇㄹ','2025-11-20 00:59:59'),(5,'neutral','ㅇㄻㄴㅇㄻ','2025-11-20 01:00:10'),(6,'neutral','ㅇㄹㅇㄹㄴㅇㄹ','2025-11-20 01:04:25'),(7,'neutral','ㅇㄹㅇㄹㄴㅇㄹ','2025-11-20 01:04:26'),(8,'neutral','ㅇㄹㅇㄹㄴㅇㄹ','2025-11-20 01:04:27'),(9,'neutral','ㅇㄹㅇㄹㄴㅇㄹ','2025-11-20 01:04:46'),(10,'neutral','ㅇㄻㄴㅇㄻㄴㅇㄹㅇㅁㄹ','2025-11-20 01:04:50'),(11,'joy','세종아 기쁘지?','2025-11-20 02:39:48'),(12,'joy','세종아 기쁘지?','2025-11-20 02:39:50'),(13,'joy','ㄹ','2025-11-20 02:40:11'),(14,'sadness','세종아 슬프니?','2025-11-20 02:43:57');
/*!40000 ALTER TABLE `emotion_comments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-02 16:43:51
