-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: emotion_db
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `emotion_logs`
--

DROP TABLE IF EXISTS `emotion_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emotion_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `emotion_code` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `user_input` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emotion_logs`
--

LOCK TABLES `emotion_logs` WRITE;
/*!40000 ALTER TABLE `emotion_logs` DISABLE KEYS */;
INSERT INTO `emotion_logs` VALUES (1,'sadness','슬픔','2025-11-20 00:53:26'),(2,'joy','오늘 코딩 오류가 너무 많이나서 아침부터 힘들다 힐링하고싶지만 신나는 노래 틀어줘','2025-11-20 00:54:00'),(3,'sadness','오늘 슬픈데 웃고싶어','2025-11-20 00:54:19'),(4,'sadness','오늘 슬픈데 웃고싶어','2025-11-20 00:54:20'),(5,'anger','시발','2025-11-20 00:55:25'),(6,'anger','좆','2025-11-20 00:55:37'),(7,'anger','좆','2025-11-20 00:55:38'),(8,'joy','너 똑똑하다','2025-11-20 00:55:48'),(9,'joy','오늘 기분이 좋아요','2025-11-20 00:57:02'),(10,'sadness','슬프네요','2025-11-20 00:57:08'),(11,'neutral','ㅇㄻㅇㄴㄻㄴㅇㄹ','2025-11-20 01:00:08'),(12,'joy','아 배고파 기분좋아','2025-11-20 01:03:54'),(13,'anger','짜증나','2025-11-20 01:04:09'),(14,'neutral','짜장면','2025-11-20 01:04:18'),(15,'neutral','짜장면','2025-11-20 01:04:20'),(16,'neutral','','2025-11-20 01:04:27'),(17,'neutral','','2025-11-20 01:04:28'),(18,'neutral','','2025-11-20 01:05:08'),(19,'neutral','짜장면','2025-11-20 01:05:19'),(20,'sadness','댓글이 안달려서 스트레스 받아','2025-11-20 01:05:53'),(21,'anger','아우 패고싶어','2025-11-20 01:05:58'),(22,'joy','골든 듣고싶다','2025-11-20 01:07:38'),(23,'joy','골든 듣고싶다','2025-11-20 01:07:40'),(24,'joy','black pink노래 듣고싶어','2025-11-20 01:08:10'),(25,'anger','짜증나','2025-11-20 01:21:49'),(26,'sadness','슬픔','2025-11-20 01:25:29'),(27,'sadness','감정통계보기떄문에 감정상함','2025-11-20 01:40:15'),(28,'neutral','ㅇㄹ','2025-11-20 01:53:58'),(29,'sadness','어제 오랜만에 운동을 했더니 온몸이 아파서 움직이지를 못하겠어','2025-11-20 01:54:42'),(30,'joy','다 만든거 같아서 기쁘다','2025-11-20 02:39:37'),(31,'neutral','','2025-11-20 02:39:50'),(32,'neutral','','2025-11-20 02:39:51'),(33,'joy','기쁘다','2025-11-20 02:40:03'),(34,'neutral','','2025-11-20 02:40:12'),(35,'sadness','나 오늘 우울하고 슬퍼ㅜㅜ','2025-11-20 02:43:47');
/*!40000 ALTER TABLE `emotion_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-02 16:43:51
